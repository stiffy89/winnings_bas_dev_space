sap.ui.define(['sap/ui/core/UIComponent'],
	function(UIComponent) {
	"use strict";

	var Component = UIComponent.extend("ns.create_order.Component", {

		metadata : {
			manifest: "json"
		}
	});

	return Component;

});
